<?php
$name = $_POST['name'];
if(empty($_POST['name']))
{
$name_error="please enter the name";
echo "$name_error</br>";
}
$phoneno = $_POST['phoneno'];
if(empty($_POST['phoneno']))
{
$phoneno_error="please enter the phoneno";
echo "$phoneno_error</br>";
}
$tableno = $_POST['tableno'];
if(empty($_POST['tableno']))
{
$tableno_error="please enter the tableno";
echo "$tableno_error</br>";
}
$quantity = $_POST['quantity'];
if(empty($_POST['quantity']))
{
$quantity_error="please enter the quantity";
echo "$quantity_error</br>";
}
$itemname = $_POST['itemname'];
if(empty($_POST['itemname']))
{
$itemname_error="please enter the itemname";
echo "$itemname_error</br>";
}
$cost = $_POST['cost'];
if(empty($_POST['cost']))
{
$cost_error="please enter the cost";
echo "$cost_error</br>";
}
if(!null==($name&&$phoneno&&$tableno&&$cost&&$quantity&&$itemname))
{
echo "<b>ORDER SCUCCESSFULLY</b>";
}
$conn = new mysqli('localhost','root','','order');
if($conn->connect_error)
{
die('Connection Failed : '. $conn->connect_error);
}
else
{
    $stmt = $conn->prepare("insert into tests(name,phoneno,tableno,quantity,itemname,cost)
	values(?,?,?,?,?,?)");
	$stmt->bind_param("siiisi", $name, $phoneno, $tableno, $quantity, $itemname, $cost);
	$stmt->execute();
	$stmt->close();
	$conn->close();
}	
?>
